-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 25, 2021 at 01:24 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `messenger`
--

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `mid` int(11) NOT NULL,
  `text` varchar(255) NOT NULL,
  `author_id` int(20) NOT NULL,
  `room_id` int(20) NOT NULL,
  `ts` int(11) NOT NULL,
  `author_name` varchar(225) NOT NULL,
  `author_img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`mid`, `text`, `author_id`, `room_id`, `ts`, `author_name`, `author_img`) VALUES
(5, 'a', 359500073, 36356948, 1616673503, 'Tam 11a', 'user-img-120391123.png'),
(6, 'ki!', 359500073, 36356948, 1616673830, 'Tam 11a', 'user-img-120391123.png'),
(7, ':/', 359500073, 36356948, 1616674250, 'Tam 11a', 'user-img-120391123.png'),
(8, 'klll', 493130542, 36356948, 1616674468, 'name nai', 'user-img-120391123.png'),
(9, 'klll;ll;l', 493130542, 36356948, 1616674497, 'name nai', 'user-img-120391123.png');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `room_serial` int(11) NOT NULL,
  `room_id` int(200) NOT NULL,
  `room_name` varchar(100) NOT NULL,
  `room_desc` varchar(255) NOT NULL,
  `room_members` mediumtext NOT NULL,
  `room_admins` mediumtext NOT NULL,
  `room_tasks` int(11) NOT NULL,
  `room_creator` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`room_serial`, `room_id`, `room_name`, `room_desc`, `room_members`, `room_admins`, `room_tasks`, `room_creator`) VALUES
(6, 361744641, 'Messenger Project', 'Messenger Project', '359500073,1538116087,493130542', '359500073', 0, '359500073'),
(7, 371123206, 'IoT Project 001', 'IoT Project 001', '359500073,1538116087,,493130542', '359500073', 0, '359500073'),
(8, 36356948, 'projectnai', 'projectnai', '493130542,359500073,1538116087', '493130542', 0, '493130542');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `unique_id` int(200) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `img` varchar(400) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `unique_id`, `fname`, `lname`, `email`, `password`, `img`, `status`) VALUES
(7, 359500073, 'Tam', '11a', 'ibrahimsadiktamim@gmail.com', '123123', 'user-img-120391123.png', 'Hey!'),
(8, 1538116087, 'Ashd', 'Attic', 'admin@ashd.attic.com', '123123', 'user-img-120391123.png', 'Hey!'),
(9, 493130542, 'name', 'nai', 'emailnai@mail.com', 'Passwordjanina', 'user-img-120391123.png', 'Hey!');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`mid`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`room_serial`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `mid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `room_serial` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
